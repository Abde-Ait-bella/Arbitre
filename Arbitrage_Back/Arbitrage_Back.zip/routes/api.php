<?php

use App\Http\Controllers\ArbitreController;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\AvertissementCotroller;
use App\Http\Controllers\ButsController;
use App\Http\Controllers\CategoryController;
use App\Http\Controllers\change_passwordController;
use App\Http\Controllers\ChangementCotroller;
use App\Http\Controllers\ClubController;
use App\Http\Controllers\CompetitionController;
use App\Http\Controllers\delegueController;
use App\Http\Controllers\JoueurController;
use App\Http\Controllers\matcheController;
use App\Http\Controllers\SaisonController;
use App\Http\Controllers\StadeController;
use App\Http\Controllers\VilleController;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::get('/matche' , [matcheController::class, 'index'])->middleware('auth:sanctum');
Route::post('/matche' , [matcheController::class, 'store'])->middleware('auth:sanctum');
Route::put('/matche/{id}' , [matcheController::class, 'update'])->middleware('auth:sanctum');
Route::delete('/matche/{id}' , [matcheController::class, 'destroy'])->middleware('auth:sanctum');;


// Route::apiResource('avertissemet', AvertissementCotroller::class);

Route::get('/avertissement' , [AvertissementCotroller::class, 'index'])->middleware('auth:sanctum');
Route::post('/avertissement' , [AvertissementCotroller::class, 'store'])->middleware('auth:sanctum');
Route::put('/avertissement/{id}' , [AvertissementCotroller::class, 'update'])->middleware('auth:sanctum');
Route::delete('/avertissement/{id}' , [AvertissementCotroller::class, 'destroy'])->middleware('auth:sanctum');

// Route::apiResource('changement', ChangementCotroller::class);

Route::get('/changement' , [ChangementCotroller::class, 'index'])->middleware('auth:sanctum');
Route::post('/changement' , [ChangementCotroller::class, 'store'])->middleware('auth:sanctum');
Route::put('/changement/{id}' , [ChangementCotroller::class, 'update'])->middleware('auth:sanctum');
Route::delete('/changement/{id}' , [ChangementCotroller::class, 'destroy'])->middleware('auth:sanctum');

Route::get('/but' , [ButsController::class, 'index'])->middleware('auth:sanctum');
Route::post('/but' , [ButsController::class, 'store'])->middleware('auth:sanctum');
Route::put('/but/{id}' , [ButsController::class, 'update'])->middleware('auth:sanctum');
Route::delete('/but/{id}' , [ButsController::class, 'destroy'])->middleware('auth:sanctum');

//Arbitre
Route::get('/arbitre' , [ArbitreController::class, 'index'])->middleware('auth:sanctum');
Route::post('/arbitre' , [ArbitreController::class, 'store'])->middleware('auth:sanctum');
Route::put('/arbitre/{id}' , [ArbitreController::class, 'update'])->middleware('auth:sanctum');
Route::delete('/arbitre/{id}' , [ArbitreController::class, 'destroy'])->middleware('auth:sanctum');

//Delegue
Route::get('/delegue' , [delegueController::class, 'index'])->middleware('auth:sanctum');
Route::post('/delegue' , [delegueController::class, 'store'])->middleware('auth:sanctum');
Route::put('/delegue/{id}' , [delegueController::class, 'update'])->middleware('auth:sanctum');
Route::delete('/delegue/{id}' , [delegueController::class, 'destroy'])->middleware('auth:sanctum');

//Club
Route::get('/club' , [ClubController::class, 'index'])->middleware('auth:sanctum');
Route::post('/club' , [ClubController::class, 'store'])->middleware('auth:sanctum');
Route::delete('/club/{id}' , [ClubController::class, 'destroy'])->middleware('auth:sanctum');
Route::put('/club/{id}' , [ClubController::class, 'update'])->middleware('auth:sanctum');


//Stade
Route::get('/stade' , [StadeController::class, 'index'])->middleware('auth:sanctum');
Route::post('/stade' , [StadeController::class, 'store'])->middleware('auth:sanctum');
Route::put('/stade/{id}', [StadeController::class, 'update'])->middleware('auth:sanctum');
Route::delete('/stade/{id}' , [StadeController::class, 'destroy'])->middleware('auth:sanctum');

// villes
Route::get('/ville' , [VilleController::class, 'index'])->middleware('auth:sanctum');
Route::post('/ville' , [VilleController::class, 'store'])->middleware('auth:sanctum');
Route::put('/ville/{id}', [VilleController::class, 'update'])->middleware('auth:sanctum');
Route::delete('/ville/{id}' , [VilleController::class, 'destroy'])->middleware('auth:sanctum');

//competitions
Route::get('/competition' , [CompetitionController::class, 'index'])->middleware('auth:sanctum');

//saison
Route::get('/saison' , [SaisonController::class, 'index'])->middleware('auth:sanctum');

//category
Route::get('/category' , [CategoryController::class, 'index'])->middleware('auth:sanctum');

//joueur
Route::get('/joueur' , [JoueurController::class, 'index'])->middleware('auth:sanctum');
Route::post('/joueur' , [JoueurController::class, 'store'])->middleware('auth:sanctum');
Route::put('/joueur/{id}', [JoueurController::class, 'update'])->middleware('auth:sanctum');
Route::delete('/joueur/{id}' , [JoueurController::class, 'destroy'])->middleware('auth:sanctum');

//change_password
Route::post('/change_password' , [change_passwordController::class, 'update'])->middleware('auth:sanctum');

Route::get('/check-auth', [AuthController::class, 'checkAuth']);

// Route::get('/csrf-token', function () {
//     return response()->json(['token' => csrf_token()]);
// });
require __DIR__.'/auth.php';

